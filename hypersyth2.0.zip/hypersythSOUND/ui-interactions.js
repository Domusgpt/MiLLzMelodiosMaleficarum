/**
 * MELODIOUS MALEFICARUM - Core UI Interactions v1.4 REFACTORED
 * Interacts directly with the new AudioEngine architecture.
 * Sets up base UI event listeners, initializes core modules, handles sidebar view toggling,
 * manages active sound source via VoiceManager, and provides global instances/state.
 */
// REMOVE: import SoundModule from '../sound/sound-module.js';
import { AudioEngine } from '../sound/AudioEngine.js'; // Adjust path as needed
import { ModuleRegistry } from '../sound/ModuleRegistry.js';
import { ParameterBridge } from '../sound/ParameterBridge.js';
import { VoiceManager } from '../sound/modules/VoiceManager.js';
import { OscillatorModule } from '../sound/modules/OscillatorModule.js';
import { FilterModule } from '../sound/modules/FilterModule.js';
import { EnvelopeModule } from '../sound/modules/EnvelopeModule.js';
import { ReverbModule } from '../sound/modules/ReverbModule.js';
// Import other necessary modules (Delay, LFO, Noise etc. when created)
// import { DelayModule } from '../sound/modules/DelayModule.js';

import HypercubeCore from '../core/HypercubeCore.js';
import ShaderManager from '../core/ShaderManager.js';
import GeometryManager from '../core/GeometryManager.js';
import ProjectionManager from '../core/ProjectionManager.js';
import { getPresetData, getPresetNames } from '../sound/presets.js'; // Import preset functions

document.addEventListener('DOMContentLoaded', () => {
    console.log("Core UI Interactions v1.4 REFACTORED Initializing...");

    // --- Global Instances ---
    // REMOVE: window.soundModule = null;
    window.audioEngine = null; // NEW: Main engine instance
    window.mainVisualizerCore = null;
    window.shaderManager = null; // ShaderManager might be internal to AudioEngine now? Check HypercubeCore constructor. Assuming separate for now.
    window.geometryManager = null;
    window.projectionManager = null;

    // --- DOM Element References (Ensure IDs match your HTML) ---
    const canvas = document.getElementById('hypercube-canvas');
    const keyboards = {
        left: document.getElementById('keyboard-left'), // Assuming ID keyboard-left
        right: document.getElementById('keyboard-right') // Assuming ID keyboard-right
    };
    const xyPads = {
        left: document.getElementById('xy-pad-left'), // Assuming ID xy-pad-left
        right: document.getElementById('xy-pad-right') // Assuming ID xy-pad-right
    };
    const xyCursors = {
        left: document.getElementById('xy-cursor-left'), // Assuming ID xy-cursor-left
        right: document.getElementById('xy-cursor-right') // Assuming ID xy-cursor-right
    };
    const sliders = document.querySelectorAll('.styled-slider'); // Keep selecting all
    const toggles = document.querySelectorAll('.toggle-switch input[type="checkbox"]'); // Keep selecting all
    const inputContainers = {
        left: document.getElementById('input-container-left'), // Assuming ID input-container-left
        right: document.getElementById('input-container-right') // Assuming ID input-container-right
    };
    const sidebarViewToggles = document.querySelectorAll('.sidebar-view-toggle');
    const sidebars = {
        left: document.getElementById('left-controls'),
        right: document.getElementById('right-controls')
    };

    // --- Core UI State (Accessible Globally) ---
    window.coreUiState = {
        activeNoteSource: null,
        activeNoteValue: null, // Actual note playing (string or null)
        activeNoteId: null, // Unique ID from VoiceManager (string or null)
        activeControlSide: null,
        xyPadActive: { left: false, right: false },
        currentPreset: 'vaporwave', // Default preset on load
        sidebarFocus: null,
        isAudioInitialized: false
    };

    // --- Mapping Helper (Crucial for Parameter Setting) ---
    // Maps UI element IDs/types to AudioEngine module IDs and parameter IDs
    // !! ADJUST THESE IDs TO MATCH YOUR ACTUAL MODULE REGISTRATION !!
    const paramMap = {
        // Sliders (Assuming IDs like slider-filter-frequency-left)
        'slider-filter-frequency': { moduleId: 'filter1', paramId: 'frequency' },
        'slider-resonance': { moduleId: 'filter1', paramId: 'resonance' }, // Assuming 'Q' is named 'resonance' in FilterModule params
        'slider-attack': { moduleId: 'ampEnv1', paramId: 'attack' }, // Assuming UI controls the main Amp Env
        'slider-release': { moduleId: 'ampEnv1', paramId: 'release' },
        // Add mappings for Osc2, LFOs, Noise etc. when UI is added
        // 'slider-osc2-mix': { moduleId: 'oscillator2', paramId: 'mix' },
        // 'slider-lfo1-rate': { moduleId: 'lfo1', paramId: 'rate' },

        // Toggles (Assuming IDs like toggle-delay-left)
        'toggle-delay': { moduleId: 'delay1', paramId: 'enabled' }, // Assuming DelayModule exists and has 'enabled' param
        'toggle-reverb': { moduleId: 'reverb1', paramId: 'enabled' },
        'toggle-arpeggiator': { moduleId: 'voiceManager', paramId: 'arpeggiatorEnabled' }, // Arp control is on VoiceManager
        'toggle-glitch': { moduleId: 'visualizer', paramId: 'glitchIntensity' }, // Special case: Visualizer param
    };

    // Helper to get mapping based on element ID (strips -left/-right)
    function getParamMapping(elementId) {
        const baseId = elementId.replace('-left', '').replace('-right', '');
        return paramMap[baseId];
    }


    // --- Initialization ---
    async function initializeApp() {
        if (!canvas) { console.error("Canvas element #hypercube-canvas not found!"); return; }

        // 1. Initialize Audio Engine (Handles internal module setup)
        try {
            window.audioEngine = new AudioEngine({ autoInit: false }); // Don't auto-init, wait for interaction

            // Register necessary module types BEFORE engine initialization if not done internally
            // Example:
            // window.audioEngine.registry.registerModuleType('VoiceManager', VoiceManager);
            // window.audioEngine.registry.registerModuleType('OscillatorModule', OscillatorModule);
            // ... etc. for Filter, Envelope, Reverb, Delay...
            // NOTE: If AudioEngine constructor handles registration, this isn't needed here.

            // Wait for the engine's initialization promise (triggered by user interaction)
            window.audioEngine.initPromise.then(success => {
                if (success) {
                    coreUiState.isAudioInitialized = true;
                    console.log("AudioEngine reports successful initialization via promise.");
                    // Now safe to update UI based on the loaded preset state
                    applyPreset(coreUiState.currentPreset); // Apply initial preset AFTER init
                } else {
                    console.error("AudioEngine initialization failed (promise resolved false).");
                    showTooltip("Audio Engine Failed to Start!", 5000, true);
                }
            }).catch(error => {
                console.error("Error during AudioEngine initialization promise:", error);
                showTooltip("Audio Engine Error!", 5000, true);
            });
            console.log("AudioEngine instance created. Initialization promise pending user interaction.");

        } catch (error) { console.error("Failed to instantiate AudioEngine:", error); return; }

        // 2. Initialize WebGL and Visualizer
        try {
            const gl = canvas.getContext('webgl', { antialias: true }) || canvas.getContext('experimental-webgl', { antialias: true });
            if (!gl) throw new Error("WebGL not supported or context creation failed.");

            window.geometryManager = new GeometryManager();
            window.projectionManager = new ProjectionManager();
            // Assuming ShaderManager needs the GL context directly
            window.shaderManager = new ShaderManager(gl, window.geometryManager, window.projectionManager);

            window.mainVisualizerCore = new HypercubeCore(canvas, window.shaderManager, {
                geometryType: 'hypercube', projectionMethod: 'perspective',
            });
            window.mainVisualizerCore.start();
            console.log("Visualizer rendering loop started.");

            requestAnimationFrame(mainUpdateLoop); // Start audio analysis -> visual sync

        } catch (error) {
            console.error("Failed to initialize WebGL/Visualizer:", error);
            canvas.outerHTML = `<div class="error-message">Error initializing WebGL Visualizer: ${error.message}</div>`;
        }

        // 3. Setup Base UI Event Listeners
        setupKeyboardListeners('left');
        setupKeyboardListeners('right');
        setupXYPadListeners('left');
        setupXYPadListeners('right');
        setupSliderListeners();
        setupToggleListeners();
        setupSidebarToggleListeners();

        // 4. Load initial preset data (but apply it fully only after audio init)
        // applyPreset(coreUiState.currentPreset); // Apply moved to after initPromise resolves

        console.log("Core UI Interactions Initialized Successfully (pending audio interaction).");
    }

    // --- Event Listener Setup Functions ---

    function setupKeyboardListeners(side) {
        const kb = keyboards[side];
        const sidebarContent = sidebars[side]?.querySelector('.sidebar-content');
        if (!kb || !sidebarContent) { console.warn(`Keyboard or sidebar content missing for side: ${side}`); return; }
        const keys = kb.querySelectorAll('.keyboard-key');

        keys.forEach(key => {
            const note = key.dataset.note;
            if (!note) return;

            const startHandler = async (e) => {
                e.preventDefault();
                if (inputContainers[side]?.dataset.activeInput !== 'keyboard') return;
                if (!sidebarContent.classList.contains('show-input')) return;

                const audioReady = await window.audioEngine.initPromise;
                if (!audioReady) {
                    showTooltip("Click/Tap interaction needed to enable audio!", 2500);
                    return;
                }

                const sourceId = `keyboard-${side}`;
                if (coreUiState.activeNoteSource && coreUiState.activeNoteSource !== sourceId) {
                    await stopCurrentlyActiveSource(false); // Use the refactored stop function
                }

                if (coreUiState.activeNoteSource === sourceId && coreUiState.activeNoteValue === note) return;

                try {
                    const voiceManager = window.audioEngine.registry.getModule('voiceManager');
                    // Use velocity 1.0 for now, can be enhanced later
                    const noteId = await voiceManager.startNote(note, 1.0); // VoiceManager now returns noteId

                    if (noteId) { // Check if note actually started
                        coreUiState.activeNoteSource = sourceId;
                        coreUiState.activeNoteValue = note;
                        coreUiState.activeNoteId = noteId; // Store the unique ID
                        coreUiState.activeControlSide = side;

                        document.querySelectorAll('.keyboard-key.active').forEach(k => k.classList.remove('active', 'key-pressed', 'key-released'));
                        key.classList.add('active', 'key-pressed');
                        key.classList.remove('key-released');

                        if (window.createParticle) { /* ... particle code ... */ }
                    } else {
                         console.warn(`VoiceManager failed to start note ${note} from ${sourceId}`);
                    }
                } catch (error) {
                    console.error(`Error starting note ${note} from ${sourceId}:`, error);
                }
            };

            const endHandler = async (e) => { // Made async
                e.preventDefault();
                // Check using the unique note ID if available, otherwise fallback to note value/source
                const expectedNoteId = coreUiState.activeNoteId;
                const expectedSource = `keyboard-${side}`;
                const expectedNoteValue = note; // The note this specific key represents

                if (coreUiState.activeNoteSource === expectedSource &&
                   (expectedNoteId || coreUiState.activeNoteValue === expectedNoteValue) ) { // Release if ID matches or if it's the right key/source

                    try {
                        const voiceManager = window.audioEngine.registry.getModule('voiceManager');
                        await voiceManager.stopNote(expectedNoteId || expectedNoteValue, true); // Pass ID if we have it, otherwise note name
                    } catch (error) {
                        console.error(`Error stopping note ${expectedNoteId || expectedNoteValue} from ${expectedSource}:`, error);
                    } finally {
                        key.classList.remove('active', 'key-pressed');
                        key.classList.add('key-released');
                        // Only reset state if the *currently* active note was the one released
                        // (Prevents race conditions if another note started before this finished)
                        if(coreUiState.activeNoteId === expectedNoteId || coreUiState.activeNoteValue === expectedNoteValue){
                            coreUiState.activeNoteSource = null;
                            coreUiState.activeNoteValue = null;
                            coreUiState.activeNoteId = null;
                            coreUiState.activeControlSide = null;
                        }
                    }
                }
            };

            // Add Listeners
            key.addEventListener('mousedown', startHandler);
            key.addEventListener('mouseup', endHandler);
            key.addEventListener('mouseleave', (e) => { if (e.buttons !== 1) { endHandler(e); }});
            key.addEventListener('touchstart', startHandler, { passive: false });
            key.addEventListener('touchend', endHandler);
            key.addEventListener('touchcancel', endHandler);
        });
    }

    function setupXYPadListeners(side) {
        const pad = xyPads[side];
        const cursor = xyCursors[side];
        const sidebarContent = sidebars[side]?.querySelector('.sidebar-content');
        if (!pad || !cursor || !sidebarContent) { /* ... warning ... */ return; }

        let isDragging = false;
        let currentNoteId = null; // Track the specific note ID for this pad

        const updateXY = (clientX, clientY) => {
            const rect = pad.getBoundingClientRect();
            let x = Math.max(0, Math.min(1, (clientX - rect.left) / rect.width));
            let y = Math.max(0, Math.min(1, (clientY - rect.top) / rect.height));

            cursor.style.left = `${x * 100}%`;
            cursor.style.top = `${y * 100}%`;

            if (!window.audioEngine) return;

            // XY Pad #1 (Sidebars) controls Filter Freq/Res via ParameterBridge
            const filterFreq = mapRangeExp(x, 0, 1, 100, 12000);
            const filterRes = mapRange(1 - y, 0, 1, 0.1, 25);
            // Use the correct mapping (assuming 'filter1' is the main filter module ID)
            window.audioEngine.parameters.setParameter('filter1', 'frequency', filterFreq);
            window.audioEngine.parameters.setParameter('filter1', 'resonance', filterRes); // Assuming FilterModule param is 'resonance'

            // Optional: Map XY to visuals only if this side is active
            if (window.mainVisualizerCore && coreUiState.activeControlSide === side) {
                window.mainVisualizerCore.updateParameters({ morphFactor: x });
            }
        };

        const startInteraction = async (clientX, clientY) => {
            if (inputContainers[side]?.dataset.activeInput !== 'xy') return;
            if (!sidebarContent.classList.contains('show-input')) return;

            const audioReady = await window.audioEngine.initPromise;
            if (!audioReady) {
                showTooltip("Click/Tap interaction needed to enable audio!", 2500);
                return;
            }

            const sourceId = `xy-pad-${side}`;
            if (coreUiState.activeNoteSource && coreUiState.activeNoteSource !== sourceId) {
                await stopCurrentlyActiveSource(false);
            }

            isDragging = true;
            coreUiState.xyPadActive[side] = true;
            pad.classList.add('active', 'touched');
            coreUiState.activeNoteSource = sourceId;
            coreUiState.activeControlSide = side;

            // Start Drone Note via VoiceManager
            const droneNote = side === 'left' ? 'A3' : 'G3';
            try {
                const voiceManager = window.audioEngine.registry.getModule('voiceManager');
                currentNoteId = await voiceManager.startNote(droneNote, 1.0); // Store the returned note ID
                if (currentNoteId) {
                    coreUiState.activeNoteValue = droneNote; // Keep track of note name too
                    coreUiState.activeNoteId = currentNoteId;
                    updateXY(clientX, clientY); // Set initial param values
                    if (window.createParticleBurst) { /* ... */ }
                } else {
                    console.warn(`Failed to start drone note ${droneNote} from ${sourceId}`);
                    // Reset state if note failed to start
                    isDragging = false;
                    coreUiState.xyPadActive[side] = false;
                    pad.classList.remove('active', 'touched');
                    coreUiState.activeNoteSource = null;
                    coreUiState.activeControlSide = null;
                }
            } catch(error) {
                console.error(`Error starting drone note ${droneNote} from ${sourceId}:`, error);
                 isDragging = false; coreUiState.xyPadActive[side] = false; pad.classList.remove('active', 'touched'); coreUiState.activeNoteSource = null; coreUiState.activeControlSide = null;
            }
        };

        const endInteraction = async () => { // Make async
            if (!isDragging || coreUiState.activeNoteSource !== `xy-pad-${side}`) return;

            isDragging = false;
            coreUiState.xyPadActive[side] = false;
            pad.classList.remove('active', 'touched');

            // Stop the specific note using its ID via VoiceManager
            if (currentNoteId) {
                try {
                    const voiceManager = window.audioEngine.registry.getModule('voiceManager');
                    await voiceManager.stopNote(currentNoteId, true); // Use ID and release
                } catch (error) {
                    console.error(`Error stopping XY pad note ${currentNoteId}:`, error);
                } finally {
                     // Only reset state if the note being stopped is the currently tracked one
                     if(coreUiState.activeNoteId === currentNoteId) {
                         coreUiState.activeNoteSource = null;
                         coreUiState.activeNoteValue = null;
                         coreUiState.activeNoteId = null;
                         coreUiState.activeControlSide = null;
                     }
                     currentNoteId = null; // Clear the tracked ID for this pad interaction
                }
            } else {
                 // Fallback if somehow ID was lost, try stopping the generic source
                 if (coreUiState.activeNoteSource === `xy-pad-${side}`) {
                     await stopCurrentlyActiveSource(true);
                 }
            }
        };

        // Add Listeners (Mouse/Touch) - Same as before
        pad.addEventListener('mousedown', (e) => startInteraction(e.clientX, e.clientY));
        document.addEventListener('mousemove', (e) => { if (isDragging && coreUiState.activeControlSide === side) updateXY(e.clientX, e.clientY); });
        document.addEventListener('mouseup', () => { if (isDragging && coreUiState.activeControlSide === side) endInteraction(); });
        pad.addEventListener('touchstart', (e) => { e.preventDefault(); startInteraction(e.changedTouches[0].clientX, e.changedTouches[0].clientY); }, { passive: false });
        document.addEventListener('touchmove', (e) => { if (isDragging && coreUiState.activeControlSide === side) { e.preventDefault(); updateXY(e.changedTouches[0].clientX, e.changedTouches[0].clientY); }}, { passive: false });
        document.addEventListener('touchend', (e) => { if (isDragging && coreUiState.activeControlSide === side) { endInteraction(); }});
        document.addEventListener('touchcancel', (e) => { if (isDragging && coreUiState.activeControlSide === side) { endInteraction(); }});

    }

    // Refactored Stop Function (Now Global)
    async function stopCurrentlyActiveSource(useRelease = false) {
        const source = coreUiState.activeNoteSource;
        const noteId = coreUiState.activeNoteId; // Get the unique ID
        if (!source || !window.audioEngine) return;

        const audioReady = await window.audioEngine.initPromise;
        if (!audioReady) {
            console.warn("Cannot stop source, audio not ready.");
            // Reset state anyway
            coreUiState.activeNoteSource = null; coreUiState.activeNoteValue = null; coreUiState.activeNoteId = null; coreUiState.activeControlSide = null;
            return;
        }

        try {
            const voiceManager = window.audioEngine.registry.getModule('voiceManager');
            // Use the note ID if available, otherwise fallback to note name (might not work correctly for polyphony)
            await voiceManager.stopNote(noteId || coreUiState.activeNoteValue, useRelease);
        } catch (error) {
            console.error(`Error stopping active source ${source} (ID: ${noteId}):`, error);
        } finally {
            // Clear UI states for the stopped source - Same as before
            if (source.startsWith('keyboard-')) { /* ... */ }
            else if (source.startsWith('xy-pad-')) { /* ... */ }
            else if (source === 'visualizer') { /* ... */ }

            // Reset core state tracking
            coreUiState.activeNoteSource = null; coreUiState.activeNoteValue = null; coreUiState.activeNoteId = null; coreUiState.activeControlSide = null;
        }
    }
    window.stopCurrentlyActiveSource = stopCurrentlyActiveSource; // Make global


    function setupSliderListeners() {
        sliders.forEach(slider => {
            updateSliderVisualFill(slider); // Initialize

            slider.addEventListener('input', (e) => {
                const sliderId = e.target.id;
                const side = sliderId.endsWith('-left') ? 'left' : sliderId.endsWith('-right') ? 'right' : null;
                const value = parseFloat(e.target.value);

                if (side && !sidebars[side]?.querySelector('.sidebar-content')?.classList.contains('show-params')) {
                    return; // Ignore if view not active
                }

                updateSliderVisualFill(e.target);

                if (!window.audioEngine) return;

                // NEW: Use ParameterBridge
                const mapping = getParamMapping(sliderId);
                if (mapping) {
                    if (mapping.moduleId === 'visualizer') { // Handle visualizer params directly
                        if (window.mainVisualizerCore) {
                            window.mainVisualizerCore.updateParameters({ [mapping.paramId]: value });
                        }
                    } else {
                        // Set parameter via the bridge
                        window.audioEngine.parameters.setParameter(mapping.moduleId, mapping.paramId, value);
                    }

                    // Sync the other side's slider
                    const otherSide = side === 'left' ? 'right' : 'left';
                    const otherSliderId = sliderId.replace(`-${side}`, `-${otherSide}`);
                    updateSliderValueAndVisual(otherSliderId, value);
                } else {
                    console.warn(`No parameter mapping found for slider: ${sliderId}`);
                }
            });
        });
    }

    function setupToggleListeners() {
        toggles.forEach(toggle => {
            toggle.addEventListener('change', (e) => {
                const toggleId = e.target.id;
                const side = toggleId.endsWith('-left') ? 'left' : toggleId.endsWith('-right') ? 'right' : null;
                const isActive = e.target.checked;

                 if (side && !sidebars[side]?.querySelector('.sidebar-content')?.classList.contains('show-params')) {
                     e.target.checked = !isActive; // Revert state
                     return; // Ignore if view not active
                 }

                if (!window.audioEngine) return;

                // NEW: Use ParameterBridge
                const mapping = getParamMapping(toggleId);
                if (mapping) {
                     if (mapping.moduleId === 'visualizer') { // Handle visualizer params directly
                         if (window.mainVisualizerCore) {
                             // Assume glitchIntensity is 0 or 0.5 for on/off
                             window.mainVisualizerCore.updateParameters({ [mapping.paramId]: isActive ? 0.5 : 0.0 });
                             console.log(`Visualizer Glitch set to ${isActive}`);
                         }
                         // Optionally still set a corresponding param in ParameterBridge if modules need to know
                         // window.audioEngine.parameters.setParameter('visualEffects', 'glitchEnabled', isActive);
                     } else {
                         // Set parameter via the bridge (e.g., 'delay1', 'enabled', true)
                         window.audioEngine.parameters.setParameter(mapping.moduleId, mapping.paramId, isActive);
                     }

                     // Sync the other side's toggle
                     const otherSide = side === 'left' ? 'right' : 'left';
                     const otherToggleId = toggleId.replace(`-${side}`, `-${otherSide}`);
                     updateToggleState(otherToggleId, isActive);

                     if (window.createParticle) { /* ... particle code ... */ }

                } else {
                     console.warn(`No parameter mapping found for toggle: ${toggleId}`);
                }
            });
        });
    }

    function setupSidebarToggleListeners() { // Logic remains mostly the same
        sidebarViewToggles.forEach(button => {
            // Use unique data-target-sidebar attribute from HTML
            const targetSidebarId = button.closest('.sidebar').id; // Get parent sidebar ID
            if (!targetSidebarId) return;
            button.dataset.targetSidebar = targetSidebarId; // Store it if not already set

            button.addEventListener('click', () => {
                const sidebarContent = document.querySelector(`#${targetSidebarId} .sidebar-content`);
                if (sidebarContent) {
                    const showingInput = sidebarContent.classList.toggle('show-input');
                    sidebarContent.classList.toggle('show-params', !showingInput);
                    button.textContent = showingInput ? 'Show Params' : 'Show Input';

                    // Stop sound if switching away from the active input view ON THIS SIDE
                    const side = targetSidebarId.startsWith('left') ? 'left' : 'right';
                    if (!showingInput && coreUiState.activeControlSide === side && (coreUiState.activeNoteSource?.startsWith('keyboard-') || coreUiState.activeNoteSource?.startsWith('xy-pad-'))) {
                        stopCurrentlyActiveSource(false); // Use the global stop function
                    }
                }
            });
        });
        console.log("Sidebar view toggle listeners attached.");
    }


    // --- UI Update Functions ---

    // Global function to update UI from the NEW engine state
    window.updateUIFromEngineState = function() {
        if (!window.audioEngine || !coreUiState.isAudioInitialized) {
             // console.warn("Cannot update UI: AudioEngine not ready.");
             return;
        }
        const parameters = window.audioEngine.parameters;

        // Helper to safely get param value
        const getParam = (moduleId, paramId, defaultValue = null) => {
            const val = parameters.getParameter(moduleId, paramId);
            return val !== undefined ? val : defaultValue;
        };

        // --- Update Sliders (Both Sides) ---
        const filterFreq = getParam('filter1', 'frequency', 1500);
        const filterRes = getParam('filter1', 'resonance', 1.0);
        const envAttack = getParam('ampEnv1', 'attack', 0.05);
        const envRelease = getParam('ampEnv1', 'release', 0.5);

        updateSliderValueAndVisual('slider-filter-frequency-left', filterFreq);
        updateSliderValueAndVisual('slider-resonance-left', filterRes);
        updateSliderValueAndVisual('slider-attack-left', envAttack);
        updateSliderValueAndVisual('slider-release-left', envRelease);
        updateSliderValueAndVisual('slider-filter-frequency-right', filterFreq);
        updateSliderValueAndVisual('slider-resonance-right', filterRes);
        updateSliderValueAndVisual('slider-attack-right', envAttack);
        updateSliderValueAndVisual('slider-release-right', envRelease);
        // Add updates for Osc2, LFO etc. sliders here when added

        // --- Update Toggles (Both Sides) ---
        const delayActive = getParam('delay1', 'enabled', false);
        const reverbActive = getParam('reverb1', 'enabled', false);
        const arpActive = getParam('voiceManager', 'arpeggiatorEnabled', false);
        // Glitch state might be read directly from visualizer or a dedicated param
        const glitchActive = window.mainVisualizerCore?.state.glitchIntensity > 0; // Example direct read

        updateToggleState('toggle-delay-left', delayActive);
        updateToggleState('toggle-reverb-left', reverbActive);
        updateToggleState('toggle-arpeggiator-left', arpActive);
        updateToggleState('toggle-glitch-left', glitchActive);
        updateToggleState('toggle-delay-right', delayActive);
        updateToggleState('toggle-reverb-right', reverbActive);
        updateToggleState('toggle-arpeggiator-right', arpActive);
        updateToggleState('toggle-glitch-right', glitchActive);

        // console.log("UI updated from AudioEngine state.");
    }

    // Updates a single slider's value and its visual fill - unchanged
    function updateSliderValueAndVisual(sliderId, value) { /* ... */ }
    // Updates a single toggle's checked state - unchanged
    function updateToggleState(toggleId, isActive) { /* ... */ }
    // Helper to update slider fill CSS variable - unchanged
    function updateSliderVisualFill(sliderElement) { /* ... */ }


    // --- Preset Application Function ---
    function applyPreset(presetName) {
        if (!window.audioEngine || !coreUiState.isAudioInitialized) {
            console.warn(`Cannot apply preset ${presetName}: AudioEngine not ready.`);
            return;
        }
        console.log(`Applying preset via AudioEngine: ${presetName}`);
        const presetData = getPresetData(presetName); // Get merged preset data

        if (!presetData) {
            console.error(`Preset data for '${presetName}' is invalid.`);
            return;
        }

        try {
            window.audioEngine.parameters.beginBatchUpdate();

            // Iterate through preset data and set parameters
            // This requires mapping the preset structure to module/param IDs
            // Example mapping (needs to be comprehensive):
            if (presetData.oscillator) {
                // Assuming VoiceManager handles distributing global osc params
                // Or maybe we have global osc modules? Let's assume global for now.
                if (presetData.oscillator.type !== undefined) window.audioEngine.parameters.setParameter('oscillator1', 'waveform', presetData.oscillator.type); // Check param name in OscillatorModule
                if (presetData.oscillator.gain !== undefined) window.audioEngine.parameters.setParameter('oscillator1', 'gain', presetData.oscillator.gain);
            }
             if (presetData.osc2) {
                if (presetData.osc2.type !== undefined) window.audioEngine.parameters.setParameter('oscillator2', 'waveform', presetData.osc2.type);
                if (presetData.osc2.detune !== undefined) window.audioEngine.parameters.setParameter('oscillator2', 'detune', presetData.osc2.detune);
                if (presetData.osc2.mix !== undefined) window.audioEngine.parameters.setParameter('oscillator2', 'mix', presetData.osc2.mix);
                 // Enable/disable Osc2 based on mix
                 window.audioEngine.parameters.setParameter('oscillator2', 'enabled', presetData.osc2.mix > 0.01);
            }
            if (presetData.filter) {
                if (presetData.filter.type !== undefined) window.audioEngine.parameters.setParameter('filter1', 'type', presetData.filter.type);
                if (presetData.filter.frequency !== undefined) window.audioEngine.parameters.setParameter('filter1', 'frequency', presetData.filter.frequency);
                if (presetData.filter.Q !== undefined) window.audioEngine.parameters.setParameter('filter1', 'resonance', presetData.filter.Q); // Map Q to 'resonance' if needed
            }
            if (presetData.envelope) {
                if (presetData.envelope.attack !== undefined) window.audioEngine.parameters.setParameter('ampEnv1', 'attack', presetData.envelope.attack);
                if (presetData.envelope.release !== undefined) window.audioEngine.parameters.setParameter('ampEnv1', 'release', presetData.envelope.release);
                 // Set filter env params too if controlled separately
                 if (presetData.envelope.attack !== undefined) window.audioEngine.parameters.setParameter('filterEnv1', 'attack', presetData.envelope.attack);
                 if (presetData.envelope.release !== undefined) window.audioEngine.parameters.setParameter('filterEnv1', 'release', presetData.envelope.release);
            }
             if (presetData.lfo1) { // Example for LFO
                 if (presetData.lfo1.rate !== undefined) window.audioEngine.parameters.setParameter('lfo1', 'rate', presetData.lfo1.rate);
                 if (presetData.lfo1.depth !== undefined) window.audioEngine.parameters.setParameter('lfo1', 'depth', presetData.lfo1.depth);
                 if (presetData.lfo1.shape !== undefined) window.audioEngine.parameters.setParameter('lfo1', 'waveform', presetData.lfo1.shape);
                 // LFO target might need special handling via modulation matrix/routing system later
            }
            if (presetData.voice) { // VoiceManager global params
                 if (presetData.voice.portamento !== undefined) window.audioEngine.parameters.setParameter('voiceManager', 'portamento', presetData.voice.portamento);
                 if (presetData.voice.unisonCount !== undefined) window.audioEngine.parameters.setParameter('voiceManager', 'unisonCount', presetData.voice.unisonCount);
                 if (presetData.voice.unisonDetune !== undefined) window.audioEngine.parameters.setParameter('voiceManager', 'unisonDetune', presetData.voice.unisonDetune);
                 // Ensure voice mode matches unison count
                 if (presetData.voice.unisonCount > 1) window.audioEngine.parameters.setParameter('voiceManager', 'voiceMode', 'unison');
                 else if (window.audioEngine.parameters.getParameter('voiceManager','voiceMode') === 'unison') window.audioEngine.parameters.setParameter('voiceManager', 'voiceMode', 'mono'); // Revert from unison if count is 1
            }

            // Effects
            if (presetData.effects) {
                if (presetData.effects.delay) {
                    if (presetData.effects.delay.time !== undefined) window.audioEngine.parameters.setParameter('delay1', 'time', presetData.effects.delay.time);
                    if (presetData.effects.delay.feedback !== undefined) window.audioEngine.parameters.setParameter('delay1', 'feedback', presetData.effects.delay.feedback);
                    if (presetData.effects.delay.active !== undefined) window.audioEngine.parameters.setParameter('delay1', 'enabled', presetData.effects.delay.active);
                }
                if (presetData.effects.reverb) {
                    if (presetData.effects.reverb.decay !== undefined) window.audioEngine.parameters.setParameter('reverb1', 'decayTime', presetData.effects.reverb.decay); // Param name might be decayTime
                    if (presetData.effects.reverb.wet !== undefined) window.audioEngine.parameters.setParameter('reverb1', 'mix', presetData.effects.reverb.wet); // Param name might be mix
                    if (presetData.effects.reverb.active !== undefined) window.audioEngine.parameters.setParameter('reverb1', 'enabled', presetData.effects.reverb.active);
                }
                if (presetData.effects.arpeggiator) {
                    if (presetData.effects.arpeggiator.rate !== undefined) window.audioEngine.parameters.setParameter('voiceManager', 'arpRate', presetData.effects.arpeggiator.rate);
                    if (presetData.effects.arpeggiator.pattern !== undefined) window.audioEngine.parameters.setParameter('voiceManager', 'arpPattern', presetData.effects.arpeggiator.pattern);
                    if (presetData.effects.arpeggiator.active !== undefined) window.audioEngine.parameters.setParameter('voiceManager', 'arpeggiatorEnabled', presetData.effects.arpeggiator.active);
                }
                 if (presetData.effects.glitch && window.mainVisualizerCore) { // Visual Glitch
                    window.mainVisualizerCore.updateParameters({ glitchIntensity: presetData.effects.glitch.active ? 0.5 : 0.0 });
                }
            }

            window.audioEngine.parameters.endBatchUpdate();

            // Update UI controls to reflect the new state
            window.updateUIFromEngineState(); // Use the globally exposed function

            coreUiState.currentPreset = presetName; // Update tracked preset

        } catch (error) {
            console.error(`Error applying preset '${presetName}' parameters:`, error);
            window.audioEngine.parameters.endBatchUpdate(); // Ensure batch ends on error
        }
    }
    window.applyPreset = applyPreset; // Expose globally for enhanced-ui preset wheel


    // --- Main Update Loop (Audio Analysis -> Visuals) ---
    function mainUpdateLoop() {
        if (window.audioEngine?.state?.isInitialized && window.mainVisualizerCore?.state?.isRendering) {
            try {
                // Read analysis data
                const analysisData = window.audioEngine.analysis.getAllAnalysisData(); // Use the new analysis module
                const audioLevels = analysisData.frequencyBands; // Assuming structure {bass, mid, high, lowMid, highMid}

                // Read parameters from ParameterBridge
                const parameters = window.audioEngine.parameters;
                const filterFreq = parameters.getParameter('filter1', 'frequency') ?? 1500;
                const filterRes = parameters.getParameter('filter1', 'resonance') ?? 1.0;
                const envAttack = parameters.getParameter('ampEnv1', 'attack') ?? 0.1;
                const glitchActive = window.mainVisualizerCore.state.glitchIntensity > 0; // Read from visualizer state directly

                // Mapping audio/synth state to visual parameters (Similar logic, reading from new sources)
                const visualParams = {
                    audioBass: audioLevels.bass,
                    audioMid: audioLevels.mid, // Use combined mid or specific bands (lowMid/highMid)
                    audioHigh: audioLevels.high,
                    currentNoteFrequency: analysisData.frequency, // Get freq from analysis data (via VoiceManager)

                    morphFactor: mapRange(filterFreq, 20, 15000, 0, 1) * (0.8 + audioLevels.mid * 0.4),
                    rotationSpeed: 0.1 + envAttack * 0.5 + audioLevels.mid * 0.3,
                    gridDensity: 4 + filterRes * 0.5 + audioLevels.bass * 6,
                    glitchIntensity: glitchActive ? (0.1 + audioLevels.high * 0.8) : 0.0,
                    universeModifier: 1.0 + (audioLevels.bass - 0.4) * 0.5,
                    patternIntensity: 0.7 + audioLevels.mid * 0.6,
                    // Add mappings for spectral features, transients etc. from analysisData if desired
                    // e.g., plasmaScale: 1.0 + analysisData.spectralFeatures.centroid * 2.0,
                };

                // Ensure values are within reasonable bounds
                visualParams.morphFactor = Math.max(0, Math.min(1, visualParams.morphFactor));
                visualParams.gridDensity = Math.max(1, Math.min(25, visualParams.gridDensity));
                visualParams.universeModifier = Math.max(0.5, Math.min(1.5, visualParams.universeModifier));
                visualParams.patternIntensity = Math.max(0, Math.min(1.5, visualParams.patternIntensity));

                window.mainVisualizerCore.updateParameters(visualParams);

            } catch (error) {
                console.error("Error in mainUpdateLoop:", error);
            }
        }
        requestAnimationFrame(mainUpdateLoop); // Continue the loop
    }

    // --- Utility Functions (Unchanged) ---
    function mapRange(value, inMin, inMax, outMin, outMax) { /* ... */ }
    function mapRangeExp(value, inMin, inMax, outMin, outMax, exponent = 2) { /* ... */ }
    // Tooltip function (relies on enhanced-ui exposing it globally)
    function showTooltip(message, duration = 2000, isError = false) {
        if (window.showTooltip) {
            window.showTooltip(message, duration, isError);
        } else {
            console.log(`Tooltip: ${message}`); // Fallback
        }
    }

    // --- Start Application ---
    initializeApp();

}); // End DOMContentLoaded